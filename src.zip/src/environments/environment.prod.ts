export const environment = {
  production: true,
  serviceURL: 'http://3.109.32.232:1609/',
  login: 'api/v1/login',
  inserttask: 'api/v1/inserttask',
  gettaskdetails: 'api/v1/gettaskdetails',
  updatetaskdetails: 'api/v1/updatetaskdetails',
  getuserdetails: 'api/v1/getuserdetails',
};
