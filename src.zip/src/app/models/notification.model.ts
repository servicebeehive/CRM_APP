export class NotificationDetail {
    userid: number;
    userFcmToken: string;
    notificationTitle: string;
    notificationBody: string;
    notificationPriority: string;
}
