export class DeviceDetails {
    public userid: number;
    public clientcode: string;
    public username: string;
    public operationtype: string;
    public emailaddress: string;
    public devicetoken: string;
    public operatingsystem: string;
    public devicemodel: string;
    public deviceid: string;
}
