export class LoginDetail {
  usercode: string;
  pwd: string;
  logintype: string;
  clientcode: string;
}
