export class ReportType{
    userid: number;
    reporttypename: string;
    reporttypecode: string;
    constructor(){
        this.userid = 0;
        this.reporttypename = '';
        this.reporttypecode = '';
    }
}
