import { IntegerInputDirective } from './integer-input-directive.directive';

describe('IntegerInputDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new IntegerInputDirective();
    expect(directive).toBeTruthy();
  });
});
